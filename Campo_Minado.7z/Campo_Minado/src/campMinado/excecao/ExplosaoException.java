package campMinado.excecao;

public class ExplosaoException extends RuntimeException{
	
	private static final long serialVersionUIND = 1L;
}
